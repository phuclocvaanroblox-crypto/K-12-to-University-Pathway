package main

import (
	"encoding/json"
	"log"
	"time"
	"github.com/gorilla/websocket"
)

type Client struct {
	hub    *Hub
	conn   *websocket.Conn
	send   chan []byte
	UserID string
	Room   string
}

func (c *Client) readPump() {
	defer func() { c.hub.unregister <- c; c.conn.Close() }()
	c.conn.SetReadLimit(512 * 1024)
	c.conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	c.conn.SetPongHandler(func(string) error { c.conn.SetReadDeadline(time.Now().Add(60 * time.Second)); return nil })

	// Rate limiting: đơn giản hóa bằng ticker
	throttle := time.Tick(100 * time.Millisecond)

	for {
		_, message, err := c.conn.ReadMessage()
		if err != nil { break }
		<-throttle // Rate limit 10 msg/s
		c.hub.broadcast <- message
	}
}

func (c *Client) writePump() {
	ticker := time.NewTicker(30 * time.Second)
	defer func() { ticker.Stop(); c.conn.Close() }()
	for {
		select {
		case message, ok := <-c.send:
			if !ok { c.conn.WriteMessage(websocket.CloseMessage, []byte{}); return }
			c.conn.WriteMessage(websocket.TextMessage, message)
		case <-ticker.C:
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil { return }
		}
	}
}
