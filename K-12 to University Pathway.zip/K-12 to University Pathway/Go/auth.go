package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"
)

type UserInfo struct {
	UserID   string
	Username string
	Role     string
}

var (
	cache = make(map[string]struct {
		user    UserInfo
		expires time.Time
	})
	mu sync.Mutex
)

func VerifyToken(token string) (*UserInfo, error) {
	mu.Lock()
	if val, ok := cache[token]; ok && val.expires.After(time.Now()) {
		mu.Unlock()
		return &val.user, nil
	}
	mu.Unlock()

	client := http.Client{Timeout: 5 * time.Second}
	req, _ := http.NewRequest("GET", "http://localhost:5000/api/verify-token", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	
	resp, err := client.Do(req)
	if err != nil || resp.StatusCode != 200 {
		return nil, fmt.Errorf("invalid token")
	}
	defer resp.Body.Close()

	var user UserInfo
	json.NewDecoder(resp.Body).Decode(&user)

	mu.Lock()
	cache[token] = struct {
		user    UserInfo
		expires time.Time
	}{user, time.Now().Add(5 * time.Minute)}
	mu.Unlock()

	return &user, nil
}
