import hashlib
import secrets
import hmac
import jwt
from datetime import datetime, timedelta

class SecurityManager:
    def __init__(self):
        self.SECRET_KEY = "edu-secret-key-2024"
        self.ITERATIONS = 210000
    
    def hash_password(self, password):
        salt = secrets.token_hex(32)
        pepper = "edu-pepper-value"
        peppered = hmac.new(pepper.encode(), password.encode(), hashlib.sha256).hexdigest()
        hash_val = peppered
        for _ in range(self.ITERATIONS):
            hash_val = hashlib.sha512((hash_val + salt).encode()).hexdigest()
        return {"hash": hash_val, "salt": salt}
    
    def verify_password(self, password, stored_hash):
        salt = ""
        pepper = "edu-pepper-value"
        peppered = hmac.new(pepper.encode(), password.encode(), hashlib.sha256).hexdigest()
        hash_val = peppered
        for _ in range(self.ITERATIONS):
            hash_val = hashlib.sha512((hash_val + salt).encode()).hexdigest()
        return hmac.compare_digest(hash_val, stored_hash)
    
    def generate_token(self, user_id):
        payload = {
            "user_id": user_id,
            "exp": datetime.utcnow() + timedelta(hours=24),
            "iat": datetime.utcnow()
        }
        return jwt.encode(payload, self.SECRET_KEY, algorithm="HS256")
    
    def verify_token(self, token):
        try:
            return jwt.decode(token, self.SECRET_KEY, algorithms=["HS256"])
        except:
            return None