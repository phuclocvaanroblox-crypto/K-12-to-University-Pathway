from flask import Flask, jsonify, request
from flask_cors import CORS
from security import SecurityManager
from database import Database
from analytics import Analytics

app = Flask(__name__)
CORS(app)
db = Database()
security = SecurityManager()
analytics = Analytics()

@app.route('/api/health')
def health():
    return jsonify({"status": "healthy", "service": "Python Backend"})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    user = db.get_user(data['username'])
    if user and security.verify_password(data['password'], user['password_hash']):
        token = security.generate_token(user['id'])
        return jsonify({"token": token, "user": {"id": user['id'], "username": user['username'], "role": user['role']}})
    return jsonify({"error": "Invalid credentials"}), 401

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    hashed = security.hash_password(data['password'])
    user_id = db.create_user(data['username'], hashed['hash'])
    return jsonify({"id": user_id, "message": "User created"})

@app.route('/api/students')
def get_students():
    grade_id = request.args.get('grade_id')
    return jsonify(db.get_students(grade_id))

@app.route('/api/students/<int:id>')
def get_student(id):
    student = db.get_student_by_id(id)
    if student:
        return jsonify(student)
    return jsonify({"error": "Not found"}), 404

@app.route('/api/students', methods=['POST'])
def add_student():
    data = request.json
    student_id = db.add_student(data['name'], data['email'], data['grade_id'])
    return jsonify({"id": student_id, "message": "Student added"}), 201

@app.route('/api/students/<int:id>', methods=['PUT'])
def update_student(id):
    data = request.json
    db.update_student(id, data['name'], data['email'], data['grade_id'])
    return jsonify({"message": "Student updated"})

@app.route('/api/students/<int:id>', methods=['DELETE'])
def delete_student(id):
    db.delete_student(id)
    return jsonify({"message": "Student deleted"})

@app.route('/api/grades')
def get_grades():
    return jsonify(db.get_all_grades())

@app.route('/api/scores')
def get_scores():
    student_id = request.args.get('student_id')
    return jsonify(db.get_scores(student_id))

@app.route('/api/scores', methods=['POST'])
def add_score():
    data = request.json
    score_id = db.add_score(data['student_id'], data['course_id'], data['score'])
    return jsonify({"id": score_id, "message": "Score added"}), 201

@app.route('/api/analytics/student/<int:id>')
def student_analytics(id):
    scores = db.get_student_scores(id)
    return jsonify(analytics.analyze_scores(scores))

@app.route('/api/analytics/class/<int:grade_id>')
def class_analytics(grade_id):
    scores = db.get_class_scores(grade_id)
    return jsonify(analytics.analyze_scores(scores))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)