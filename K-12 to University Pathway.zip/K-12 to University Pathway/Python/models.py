from dataclasses import dataclass, asdict

@dataclass
class Student:
    id: int
    name: str
    email: str
    grade_id: int
    created_at: str = ""
    def to_dict(self):
        return asdict(self)

@dataclass
class Grade:
    id: int
    name: str
    level: str
    def to_dict(self):
        return asdict(self)

@dataclass
class Score:
    id: int
    student_id: int
    course_id: int
    score: float
    exam_date: str = ""
    def to_dict(self):
        return asdict(self)

@dataclass
class User:
    id: int
    username: str
    password_hash: str
    role: str = "student"
    def to_dict(self):
        return asdict(self)