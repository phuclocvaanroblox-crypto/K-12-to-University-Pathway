import statistics

class Analytics:
    def analyze_scores(self, scores):
        if not scores:
            return {"error": "No data", "count": 0}
        return {
            "count": len(scores),
            "average": round(statistics.mean(scores), 2),
            "median": round(statistics.median(scores), 2),
            "min": min(scores),
            "max": max(scores),
            "std_dev": round(statistics.stdev(scores), 2) if len(scores) > 1 else 0,
            "pass_rate": round(sum(1 for s in scores if s >= 5) / len(scores) * 100, 1)
        }
    
    def classify_grade(self, score):
        if score >= 9.0:
            return "Xuất sắc (A+)"
        elif score >= 8.5:
            return "Giỏi (A)"
        elif score >= 7.0:
            return "Khá (B)"
        elif score >= 5.0:
            return "Trung bình (C)"
        elif score >= 3.5:
            return "Yếu (D)"
        return "Kém (F)"
    
    def predict_performance(self, history):
        if not history or len(history) < 2:
            return "Cần thêm dữ liệu"
        avg = statistics.mean(history)
        trend = history[-1] - history[0]
        if trend > 1 and avg > 7:
            return "Tiến bộ tốt"
        elif trend > 0:
            return "Có tiến bộ"
        elif trend < -1:
            return "Cần cải thiện"
        return "Ổn định"