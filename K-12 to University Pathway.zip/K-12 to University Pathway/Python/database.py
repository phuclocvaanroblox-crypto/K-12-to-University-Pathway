import sqlite3

class Database:
    def __init__(self, db_path="education.db"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_tables()
        self._seed_data()
    
    def _init_tables(self):
        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'student',
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                grade_id INTEGER,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS grades (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                level TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                course_id INTEGER,
                score REAL,
                exam_date TEXT DEFAULT (datetime('now'))
            );
        ''')
        self.conn.commit()
    
    def _seed_data(self):
        grades = [(1,'Lớp 1','primary'),(2,'Lớp 2','primary'),(3,'Lớp 3','primary'),
                  (4,'Lớp 4','primary'),(5,'Lớp 5','primary'),(6,'Lớp 6','secondary'),
                  (7,'Lớp 7','secondary'),(8,'Lớp 8','secondary'),(9,'Lớp 9','secondary'),
                  (10,'Lớp 10','high'),(11,'Lớp 11','high'),(12,'Lớp 12','high')]
        self.conn.executemany('INSERT OR IGNORE INTO grades(id,name,level) VALUES(?,?,?)', grades)
        self.conn.commit()
    
    def get_user(self, username):
        row = self.conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        return dict(row) if row else None
    
    def create_user(self, username, password_hash):
        cursor = self.conn.execute('INSERT INTO users(username,password_hash) VALUES(?,?)', (username, password_hash))
        self.conn.commit()
        return cursor.lastrowid
    
    def get_students(self, grade_id=None):
        if grade_id:
            rows = self.conn.execute('SELECT * FROM students WHERE grade_id=?', (grade_id,))
        else:
            rows = self.conn.execute('SELECT * FROM students')
        return [dict(r) for r in rows]
    
    def get_student_by_id(self, id):
        row = self.conn.execute('SELECT * FROM students WHERE id=?', (id,)).fetchone()
        return dict(row) if row else None
    
    def add_student(self, name, email, grade_id):
        cursor = self.conn.execute('INSERT INTO students(name,email,grade_id) VALUES(?,?,?)', (name, email, grade_id))
        self.conn.commit()
        return cursor.lastrowid
    
    def update_student(self, id, name, email, grade_id):
        self.conn.execute('UPDATE students SET name=?, email=?, grade_id=? WHERE id=?', (name, email, grade_id, id))
        self.conn.commit()
    
    def delete_student(self, id):
        self.conn.execute('DELETE FROM students WHERE id=?', (id,))
        self.conn.commit()
    
    def get_all_grades(self):
        return [dict(r) for r in self.conn.execute('SELECT * FROM grades ORDER BY id')]
    
    def get_scores(self, student_id=None):
        if student_id:
            rows = self.conn.execute('SELECT * FROM scores WHERE student_id=?', (student_id,))
        else:
            rows = self.conn.execute('SELECT * FROM scores')
        return [dict(r) for r in rows]
    
    def add_score(self, student_id, course_id, score):
        cursor = self.conn.execute('INSERT INTO scores(student_id,course_id,score) VALUES(?,?,?)', (student_id, course_id, score))
        self.conn.commit()
        return cursor.lastrowid
    
    def get_student_scores(self, student_id):
        rows = self.conn.execute('SELECT score FROM scores WHERE student_id=?', (student_id,))
        return [r['score'] for r in rows]
    
    def get_class_scores(self, grade_id):
        rows = self.conn.execute('SELECT s.score FROM scores s JOIN students st ON s.student_id=st.id WHERE st.grade_id=?', (grade_id,))
        return [r['score'] for r in rows]