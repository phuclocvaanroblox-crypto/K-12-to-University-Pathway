<?php

const JWT_SECRET = 'edu-secret-key-2024';

function passwordHash512($password)
{
    $hash = $password;

    for ($i = 0; $i < 210000; $i++) {
        $hash = hash('sha512', $hash);
    }

    return $hash;
}

function base64url($data)
{
    return rtrim(
        strtr(base64_encode($data), '+/', '-_'),
        '='
    );
}

function login($db, $data)
{
    if (
        empty($data['username']) ||
        empty($data['password'])
    ) {
        throw new Exception('Username and password required');
    }

    $user = $db->fetch(
        "SELECT * FROM users WHERE username=?",
        [$data['username']]
    );

    if (!$user) {
        throw new Exception('Invalid credentials');
    }

    $hash = passwordHash512($data['password']);

    if ($hash !== $user['password']) {
        throw new Exception('Invalid credentials');
    }

    $header = [
        'alg' => 'HS256',
        'typ' => 'JWT'
    ];

    $payload = [
        'id' => $user['id'],
        'username' => $user['username'],
        'exp' => time() + 86400
    ];

    $h = base64url(json_encode($header));
    $p = base64url(json_encode($payload));

    $signature = hash_hmac(
        'sha256',
        $h . '.' . $p,
        JWT_SECRET,
        true
    );

    $s = base64url($signature);

    return [
        'token' => $h . '.' . $p . '.' . $s,
        'expires_in' => 86400
    ];
}

function register($db, $data)
{
    if (
        empty($data['username']) ||
        empty($data['password'])
    ) {
        throw new Exception('Username and password required');
    }

    $exists = $db->fetch(
        "SELECT id FROM users WHERE username=?",
        [$data['username']]
    );

    if ($exists) {
        throw new Exception('Username already exists');
    }

    $id = $db->insert(
        "INSERT INTO users(username,password) VALUES(?,?)",
        [
            $data['username'],
            passwordHash512($data['password'])
        ]
    );

    return [
        'id' => $id,
        'username' => $data['username']
    ];
}

function verifyToken()
{
    $headers = getallheaders();

    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'Unauthorized'
        ]);
        exit;
    }

    $auth = $headers['Authorization'];

    if (!preg_match('/Bearer\s(\S+)/', $auth, $m)) {
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid token'
        ]);
        exit;
    }

    $token = $m[1];
    $parts = explode('.', $token);

    if (count($parts) !== 3) {
        http_response_code(401);
        exit;
    }

    [$h, $p, $s] = $parts;

    $expected = base64url(
        hash_hmac(
            'sha256',
            $h . '.' . $p,
            JWT_SECRET,
            true
        )
    );

    if ($expected !== $s) {
        http_response_code(401);
        exit;
    }

    $payload = json_decode(
        base64_decode(
            strtr($p, '-_', '+/')
        ),
        true
    );

    if ($payload['exp'] < time()) {
        http_response_code(401);
        exit;
    }

    return $payload;
}