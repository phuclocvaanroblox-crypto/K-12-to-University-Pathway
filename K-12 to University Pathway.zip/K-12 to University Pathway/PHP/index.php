<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'database.php';
require_once 'auth.php';
require_once 'api.php';

$db = new Database();

function response($status, $data = null, $message = null, $code = 200)
{
    http_response_code($code);

    if ($status === 'success') {
        echo json_encode([
            'status' => 'success',
            'data' => $data
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
    }

    exit;
}

try {
    $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $base = dirname($_SERVER['SCRIPT_NAME']);

    if ($base !== '/') {
        $uri = preg_replace('#^' . preg_quote($base) . '#', '', $uri);
    }

    $segments = array_values(array_filter(explode('/', trim($uri, '/'))));

    if (empty($segments)) {
        response('error', null, 'Not Found', 404);
    }

    if ($segments[0] !== 'api') {
        response('error', null, 'Not Found', 404);
    }

    $method = $_SERVER['REQUEST_METHOD'];
    $body = json_decode(file_get_contents('php://input'), true) ?? [];

    if (isset($segments[1]) && $segments[1] === 'health') {
        response('success', [
            'service' => 'Education API',
            'time' => date('c')
        ]);
    }

    if (isset($segments[1]) && $segments[1] === 'login' && $method === 'POST') {
        response('success', login($db, $body));
    }

    if (isset($segments[1]) && $segments[1] === 'register' && $method === 'POST') {
        response('success', register($db, $body), null, 201);
    }

    if (
        isset($segments[1]) &&
        !in_array($segments[1], ['login', 'register', 'health'])
    ) {
        verifyToken();
    }

    if (isset($segments[1]) && $segments[1] === 'students') {

        if ($method === 'GET' && isset($segments[2])) {
            response('success', getStudent($db, $segments[2]));
        }

        if ($method === 'GET') {
            response(
                'success',
                getStudents($db, $_GET['grade_id'] ?? null)
            );
        }

        if ($method === 'POST') {
            response(
                'success',
                addStudent($db, $body),
                null,
                201
            );
        }

        if ($method === 'PUT' && isset($segments[2])) {
            response(
                'success',
                updateStudent($db, $segments[2], $body)
            );
        }

        if ($method === 'DELETE' && isset($segments[2])) {
            response(
                'success',
                deleteStudent($db, $segments[2])
            );
        }
    }

    if (isset($segments[1]) && $segments[1] === 'grades') {
        response('success', getGrades($db));
    }

    if (isset($segments[1]) && $segments[1] === 'scores') {

        if ($method === 'GET') {
            response(
                'success',
                getScores($db, $_GET['student_id'] ?? null)
            );
        }

        if ($method === 'POST') {
            response(
                'success',
                addScore($db, $body),
                null,
                201
            );
        }
    }

    if (
        isset($segments[1]) &&
        $segments[1] === 'analytics' &&
        isset($segments[2]) &&
        $segments[2] === 'student' &&
        isset($segments[3])
    ) {
        response(
            'success',
            getAnalytics($db, $segments[3])
        );
    }

    response('error', null, 'Endpoint not found', 404);

} catch (Exception $e) {
    response('error', null, $e->getMessage(), 500);
}