<?php

function getStudents($db, $gradeId = null)
{
    if ($gradeId) {
        return $db->fetchAll(
            "SELECT * FROM students WHERE grade_id=?",
            [$gradeId]
        );
    }

    return $db->fetchAll(
        "SELECT * FROM students"
    );
}

function getStudent($db, $id)
{
    $student = $db->fetch(
        "SELECT * FROM students WHERE id=?",
        [$id]
    );

    if (!$student) {
        throw new Exception('Student not found');
    }

    return $student;
}

function addStudent($db, $data)
{
    $id = $db->insert(
        "INSERT INTO students(name,email,grade_id)
         VALUES(?,?,?)",
        [
            $data['name'] ?? '',
            $data['email'] ?? '',
            $data['grade_id'] ?? null
        ]
    );

    return getStudent($db, $id);
}

function updateStudent($db, $id, $data)
{
    $db->query(
        "UPDATE students
         SET name=?,
             email=?,
             grade_id=?
         WHERE id=?",
        [
            $data['name'],
            $data['email'],
            $data['grade_id'],
            $id
        ]
    );

    return getStudent($db, $id);
}

function deleteStudent($db, $id)
{
    $student = getStudent($db, $id);

    $db->query(
        "DELETE FROM students WHERE id=?",
        [$id]
    );

    return $student;
}

function getGrades($db)
{
    return $db->fetchAll(
        "SELECT * FROM grades"
    );
}

function getScores($db, $studentId = null)
{
    if ($studentId) {
        return $db->fetchAll(
            "SELECT * FROM scores
             WHERE student_id=?",
            [$studentId]
        );
    }

    return $db->fetchAll(
        "SELECT * FROM scores"
    );
}

function addScore($db, $data)
{
    $id = $db->insert(
        "INSERT INTO scores(
            student_id,
            course_id,
            score
         ) VALUES(?,?,?)",
        [
            $data['student_id'],
            $data['course_id'],
            $data['score']
        ]
    );

    return $db->fetch(
        "SELECT * FROM scores WHERE id=?",
        [$id]
    );
}

function getAnalytics($db, $studentId)
{
    return $db->fetch(
        "
        SELECT
            AVG(score) avg_score,
            MIN(score) min_score,
            MAX(score) max_score,
            COUNT(*) total_scores
        FROM scores
        WHERE student_id=?
        ",
        [$studentId]
    );
}