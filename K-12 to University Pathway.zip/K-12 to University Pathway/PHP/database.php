<?php

class Database
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = new PDO('sqlite:' . __DIR__ . '/education.db');
        $this->pdo->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

        $this->init();
    }

    private function init()
    {
        $this->execute("
            CREATE TABLE IF NOT EXISTS users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $this->execute("
            CREATE TABLE IF NOT EXISTS grades(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT
            )
        ");

        $this->execute("
            CREATE TABLE IF NOT EXISTS students(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT,
                grade_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $this->execute("
            CREATE TABLE IF NOT EXISTS scores(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                course_id INTEGER,
                score REAL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $count = $this->fetch(
            "SELECT COUNT(*) total FROM grades"
        );

        if ($count['total'] == 0) {
            $grades = [
                'Lớp 1',
                'Lớp 5',
                'Lớp 9',
                'Lớp 12'
            ];

            foreach ($grades as $g) {
                $this->insert(
                    "INSERT INTO grades(name) VALUES(?)",
                    [$g]
                );
            }
        }
    }

    public function query($sql, $params = [])
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetch($sql, $params = [])
    {
        return $this
            ->query($sql, $params)
            ->fetch(PDO::FETCH_ASSOC);
    }

    public function fetchAll($sql, $params = [])
    {
        return $this
            ->query($sql, $params)
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function insert($sql, $params = [])
    {
        $this->query($sql, $params);
        return $this->pdo->lastInsertId();
    }

    public function execute($sql)
    {
        return $this->pdo->exec($sql);
    }
}