const API_BASE = 'http://localhost:5000/api';

let currentStudentId = null;
let allStudents = [];
let allGrades = [];
let allScores = [];

document.addEventListener('DOMContentLoaded', () => {
    initializeEventListeners();
    loadInitialData();
});

function initializeEventListeners() {
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const pageId = item.dataset.page;
            showPage(pageId);
        });
    });

    document.querySelector('.toggle-sidebar').addEventListener('click', () => {
        document.querySelector('.sidebar').classList.toggle('active');
    });

    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.target.closest('.modal').classList.remove('active');
        });
    });

    document.getElementById('add-student-btn').addEventListener('click', () => {
        currentStudentId = null;
        document.getElementById('modal-title').textContent = 'Thêm Học Sinh';
        document.getElementById('student-form').reset();
        document.getElementById('student-modal').classList.add('active');
    });

    document.getElementById('cancel-student').addEventListener('click', () => {
        document.getElementById('student-modal').classList.remove('active');
    });

    document.getElementById('student-form').addEventListener('submit', handleStudentSubmit);

    document.getElementById('add-score-btn').addEventListener('click', () => {
        document.getElementById('score-form').reset();
        document.getElementById('score-modal').classList.add('active');
    });

    document.getElementById('cancel-score').addEventListener('click', () => {
        document.getElementById('score-modal').classList.remove('active');
    });

    document.getElementById('score-form').addEventListener('submit', handleScoreSubmit);

    document.getElementById('grade-filter').addEventListener('change', loadStudents);
    document.getElementById('student-filter').addEventListener('change', loadScores);

    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('active');
        }
    });
}

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => {
        p.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');

    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === pageId) {
            item.classList.add('active');
        }
    });

    const titleMap = {
        dashboard: 'Dashboard',
        students: 'Danh Sách Học Sinh',
        grades: 'Khối Lớp',
        scores: 'Điểm Số',
        schedule: 'Lịch Học'
    };
    document.querySelector('.header-title').textContent = titleMap[pageId];

    if (pageId === 'students') {
        loadStudents();
    } else if (pageId === 'grades') {
        loadGrades();
    } else if (pageId === 'scores') {
        loadScores();
    } else if (pageId === 'dashboard') {
        loadDashboard();
    }

    document.querySelector('.sidebar').classList.remove('active');
}

async function loadInitialData() {
    try {
        const [studentsRes, gradesRes] = await Promise.all([
            fetch(`${API_BASE}/students`, { headers: getAuthHeaders() }),
            fetch(`${API_BASE}/grades`, { headers: getAuthHeaders() })
        ]);

        if (studentsRes.ok) allStudents = await studentsRes.json();
        if (gradesRes.ok) allGrades = await gradesRes.json();

        populateSelects();
    } catch (error) {
        console.error('Error loading initial data:', error);
    }
}

function getAuthHeaders() {
    const token = localStorage.getItem('authToken') || 'demo-token';
    return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };
}

async function loadDashboard() {
    try {
        const res = await fetch(`${API_BASE}/students`, { headers: getAuthHeaders() });
        if (res.ok) {
            const students = await res.json();
            document.getElementById('total-students').textContent = students.length;
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

async function loadStudents() {
    try {
        const gradeId = document.getElementById('grade-filter').value;
        let url = `${API_BASE}/students`;
        if (gradeId) {
            url += `?grade_id=${gradeId}`;
        }

        const res = await fetch(url, { headers: getAuthHeaders() });
        if (res.ok) {
            const students = await res.json();
            renderStudentsTable(students);
            allStudents = students;
        }
    } catch (error) {
        console.error('Error loading students:', error);
        showToast('Lỗi tải dữ liệu học sinh', 'error');
    }
}

function renderStudentsTable(students) {
    const tbody = document.getElementById('students-tbody');
    tbody.innerHTML = '';

    students.forEach(student => {
        const gradeObj = allGrades.find(g => g.id === student.grade_id);
        const gradeName = gradeObj ? gradeObj.name : 'N/A';

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${gradeName}</td>
            <td>
                <button class="btn btn-edit btn-small" onclick="editStudent(${student.id})">
                    <i class="fas fa-edit"></i> Sửa
                </button>
                <button class="btn btn-delete btn-small" onclick="deleteStudent(${student.id})">
                    <i class="fas fa-trash"></i> Xóa
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

async function editStudent(studentId) {
    const student = allStudents.find(s => s.id === studentId);
    if (!student) return;

    currentStudentId = studentId;
    document.getElementById('modal-title').textContent = 'Chỉnh Sửa Học Sinh';
    document.getElementById('student-name').value = student.name;
    document.getElementById('student-email').value = student.email;
    document.getElementById('student-grade').value = student.grade_id;
    document.getElementById('student-modal').classList.add('active');
}

async function deleteStudent(studentId) {
    if (!confirm('Bạn chắc chắn muốn xóa học sinh này?')) return;

    try {
        const res = await fetch(`${API_BASE}/students/${studentId}`, {
            method: 'DELETE',
            headers: getAuthHeaders()
        });

        if (res.ok) {
            showToast('Xóa học sinh thành công', 'success');
            loadStudents();
        } else {
            showToast('Lỗi xóa học sinh', 'error');
        }
    } catch (error) {
        console.error('Error deleting student:', error);
        showToast('Lỗi xóa học sinh', 'error');
    }
}

async function handleStudentSubmit(e) {
    e.preventDefault();

    const name = document.getElementById('student-name').value;
    const email = document.getElementById('student-email').value;
    const gradeId = document.getElementById('student-grade').value;

    const studentData = { name, email, grade_id: parseInt(gradeId) };

    try {
        let res;
        if (currentStudentId) {
            res = await fetch(`${API_BASE}/students/${currentStudentId}`, {
                method: 'PUT',
                headers: getAuthHeaders(),
                body: JSON.stringify(studentData)
            });
        } else {
            res = await fetch(`${API_BASE}/students`, {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify(studentData)
            });
        }

        if (res.ok) {
            const message = currentStudentId ? 'Cập nhật thành công' : 'Thêm học sinh thành công';
            showToast(message, 'success');
            document.getElementById('student-modal').classList.remove('active');
            loadStudents();
        } else {
            showToast('Lỗi xử lý', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Lỗi xử lý', 'error');
    }
}

async function loadGrades() {
    try {
        const res = await fetch(`${API_BASE}/grades`, { headers: getAuthHeaders() });
        if (res.ok) {
            const grades = await res.json();
            renderGradesGrid(grades);
            allGrades = grades;
        }
    } catch (error) {
        console.error('Error loading grades:', error);
        showToast('Lỗi tải khối lớp', 'error');
    }
}

function renderGradesGrid(grades) {
    const grid = document.getElementById('grades-grid');
    grid.innerHTML = '';

    grades.forEach(grade => {
        const card = document.createElement('div');
        card.className = 'grade-card';
        card.innerHTML = `
            <div class="grade-card-icon">
                <i class="fas fa-door-open"></i>
            </div>
            <div class="grade-card-name">${grade.name}</div>
            <div class="grade-card-info">${grade.student_count || 0} học sinh</div>
        `;
        card.addEventListener('click', () => showGradeDetail(grade));
        grid.appendChild(card);
    });
}

async function showGradeDetail(grade) {
    try {
        const res = await fetch(`${API_BASE}/students?grade_id=${grade.id}`, 
            { headers: getAuthHeaders() }
        );

        if (res.ok) {
            const students = await res.json();
            document.getElementById('grade-detail-title').textContent = grade.name;

            const tbody = document.getElementById('grade-students-tbody');
            tbody.innerHTML = '';

            students.forEach(student => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${student.id}</td>
                    <td>${student.name}</td>
                    <td>${student.email}</td>
                `;
                tbody.appendChild(row);
            });

            document.getElementById('grade-detail').classList.add('active');
        }
    } catch (error) {
        console.error('Error loading grade detail:', error);
        showToast('Lỗi tải chi tiết khối lớp', 'error');
    }
}

async function loadScores() {
    try {
        const studentId = document.getElementById('student-filter').value;
        let url = `${API_BASE}/scores`;
        if (studentId) {
            url += `?student_id=${studentId}`;
        }

        const res = await fetch(url, { headers: getAuthHeaders() });
        if (res.ok) {
            const scores = await res.json();
            renderScoresTable(scores);
            allScores = scores;
        }
    } catch (error) {
        console.error('Error loading scores:', error);
        showToast('Lỗi tải điểm số', 'error');
    }
}

function renderScoresTable(scores) {
    const tbody = document.getElementById('scores-tbody');
    tbody.innerHTML = '';

    scores.forEach(score => {
        const student = allStudents.find(s => s.id === score.student_id);
        const studentName = student ? student.name : 'N/A';
        const badge = getScoreBadge(score.score);

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${studentName}</td>
            <td>${score.subject}</td>
            <td>${score.score}</td>
            <td><span class="badge badge-${badge.class}">${badge.label}</span></td>
            <td>${new Date(score.date).toLocaleDateString('vi-VN')}</td>
        `;
        tbody.appendChild(row);
    });
}

function getScoreBadge(score) {
    if (score >= 9) return { label: 'A+', class: 'a-plus' };
    if (score >= 8) return { label: 'A', class: 'a' };
    if (score >= 7) return { label: 'B', class: 'b' };
    if (score >= 6) return { label: 'C', class: 'c' };
    if (score >= 5) return { label: 'D', class: 'd' };
    return { label: 'F', class: 'f' };
}

async function handleScoreSubmit(e) {
    e.preventDefault();

    const studentId = document.getElementById('score-student').value;
    const subject = document.getElementById('score-subject').value;
    const score = parseFloat(document.getElementById('score-value').value);

    const scoreData = {
        student_id: parseInt(studentId),
        subject,
        score,
        date: new Date().toISOString()
    };

    try {
        const res = await fetch(`${API_BASE}/scores`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(scoreData)
        });

        if (res.ok) {
            showToast('Thêm điểm thành công', 'success');
            document.getElementById('score-modal').classList.remove('active');
            loadScores();
        } else {
            showToast('Lỗi thêm điểm', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Lỗi thêm điểm', 'error');
    }
}

function populateSelects() {
    const gradeFilterSelect = document.getElementById('grade-filter');
    const studentGradeSelect = document.getElementById('student-grade');
    const studentFilterSelect = document.getElementById('student-filter');
    const scoreStudentSelect = document.getElementById('score-student');

    gradeFilterSelect.innerHTML = '<option value="">Tất cả khối lớp</option>';
    studentGradeSelect.innerHTML = '<option value="">Chọn khối lớp</option>';
    studentFilterSelect.innerHTML = '<option value="">Chọn học sinh</option>';
    scoreStudentSelect.innerHTML = '<option value="">Chọn học sinh</option>';

    allGrades.forEach(grade => {
        const option = document.createElement('option');
        option.value = grade.id;
        option.textContent = grade.name;
        gradeFilterSelect.appendChild(option.cloneNode(true));
        studentGradeSelect.appendChild(option.cloneNode(true));
    });

    allStudents.forEach(student => {
        const option = document.createElement('option');
        option.value = student.id;
        option.textContent = student.name;
        studentFilterSelect.appendChild(option.cloneNode(true));
        scoreStudentSelect.appendChild(option.cloneNode(true));
    });
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast show ${type}`;

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}
